package com.cts;

public class StringCharArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "Java Programming language";
        char[] arr = str.toCharArray();
        System.out.println(arr);

	}

}
