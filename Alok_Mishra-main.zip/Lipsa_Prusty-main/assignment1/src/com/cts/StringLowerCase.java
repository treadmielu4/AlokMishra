package com.cts;

public class StringLowerCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String str = "My name is Eclipse Foundation.";

	      
	        String lowerStr = str.toLowerCase();

	        
	        System.out.println("Original String: " + str);
	        System.out.println("String in lowercase: " + lowerStr);

	}

}
