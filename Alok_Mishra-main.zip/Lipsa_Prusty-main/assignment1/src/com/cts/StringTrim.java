package com.cts;

public class StringTrim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String str = " My name is Eclipse Foundation ";

	      
	        String newStr = str.trim();

	        
	        System.out.println("Original String: " + str);
	        System.out.println("New String: " + newStr);

	}

}
