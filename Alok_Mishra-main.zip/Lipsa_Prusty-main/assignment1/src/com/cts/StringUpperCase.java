package com.cts;

public class StringUpperCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String str = "my name is java prog language";

	      
	        String upperStr = str.toUpperCase();

	        
	        System.out.println("Original String: " + str);
	        System.out.println("String in Uppercase: " + upperStr);

	}

}
