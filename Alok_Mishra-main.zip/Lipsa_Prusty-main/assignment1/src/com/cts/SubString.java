package com.cts;

public class SubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String str = "My name is Google. I'm a search engine.";

	       
	        String new_str = str.substring(10, 32);

	        // Display the two strings for comparison.
	        System.out.println("old = " + str);
	        System.out.println("new = " + new_str);

	}

}
